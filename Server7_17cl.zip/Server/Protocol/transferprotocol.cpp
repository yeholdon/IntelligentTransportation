#include "transferprotocol.h"

TransferProtocol::TransferProtocol(QObject *parent) : QObject(parent)
{

}
